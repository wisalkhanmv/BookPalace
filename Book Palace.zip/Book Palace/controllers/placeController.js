const asyncHandler = require("express-async-handler");
const { render } = require("express/lib/response");
const { DEC8_BIN } = require("mysql/lib/protocol/constants/charsets");
const { connect } = require("../database.js");
const connection = require("../database.js");

// @desc    Get user data
// @route   GET /api/users/me
// @access  Private
const registerPlace = asyncHandler(async (req, res) => {
  const {
    loc_name,
    available_from,
    available_till,
    property_type,
    space_type,
    max_guest,
    total_bedroom,
    total_bathroom,
    price_per_night,
    email,
  } = req.body;
  // res.status(200).json(req.user);
  // res.render("profile");
  // res.redirect("/getMe");
  const place = connection.query(
    "SELECT user_id,isAdmin FROM user WHERE email = ?",
    [email],
    (error, results) => {
      if (error) {
        res.render("registerPlace", { message: "Error" });
      } else if (results[0].isAdmin == "no") {
        res.render("registerPlace", { message: "You are not an admin" });
      } else {
        connection.query(
          "INSERT INTO place(loc_name,available_from,available_till,property_type,space_type,max_guest,total_bedroom,total_bathroom,price_per_night,user_id, isBooked) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
          [
            loc_name,
            available_from,
            available_till,
            property_type,
            space_type,
            max_guest,
            total_bedroom,
            total_bathroom,
            price_per_night,
            results[0].user_id,
            "no",
          ],
          (error, results) => {
            if (error) {
              console.log(error);
              console.res.render("registerPlace", { message: "Error" });
            } else {
              res.render("registerPlace", { message: "Place Registered" });
            }
          }
        );
      }
    }
  );
});

const bookPlace = asyncHandler(async (req, res) => {
  const { email, booked_from, booked_till, loc_id } = req.body;
  const place = connection.query(
    "SELECT * FROM user WHERE email = ?",
    [email],
    (error, results) => {
      if (error) {
        res.render("bookPlace", { message: "Error" });
      } else {
        const user = results[0];
        connection.query(
          "SELECT * FROM place WHERE loc_id = ?",
          [loc_id],
          (error, results) => {
            if (error) {
              res.render("bookPlace", { message: "Error" });
            } else if (results[0].isBooked == "yes") {
              res.render("bookPlace", { message: "Place is already booked" });
            } else {
              connection.query(
                "UPDATE place SET isBooked = ? WHERE loc_id = ?",
                ["yes", loc_id],
                (error, results) => {
                  if (error) {
                    res.render("bookPlace", { message: "Error" });
                  } else {
                    connection.query(
                      "INSERT INTO guest_books(user_id,loc_id,booked_from,booked_till) VALUES(?,?,?,?)",
                      [user.user_id, loc_id, booked_from, booked_till],
                      (error, results) => {
                        if (error) {
                          res.render("bookPlace", { message: "Error" });
                        } else {
                          console.log("place booked");
                          res.render("bookPlace", {
                            message: "Place Booked",
                          });
                        }
                      }
                    );
                  }
                }
              );
            }
          }
        );
      }
    }
  );
});

const getAvailablePlaces = asyncHandler(async (req, res) => {
  const places = connection.query(
    "SELECT * FROM place where isBooked=?",
    ["no"],
    (error, results) => {
      if (error) {
        res.render("availablePlaces", { message: "Couldn't get places" });
      } else {
        res.render("availablePlaces", { places: results });
        // res.json(results[0]);
      }
    }
  );
});
const addWishListPlace = asyncHandler(async (req, res) => {
  const { email, loc_id } = req.body;
  const places = connection.query(
    "SELECT user_id FROM user where email=?",
    [email],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("addWishListPlace", { message: "Couldn't get the email" });
      } else {
        const user_id = results[0].user_id;
        connection.query(
          "INSERT INTO guest_wishlist(user_id,loc_id) VALUES(?,?)",
          [user_id, loc_id],
          (error, results) => {
            if (error) {
              res.render("addWishListPlace", {
                message: "Couldn't get places",
              });
            } else {
              res.render("addWishListPlace", {
                message: "Place added to your wishlist",
              });
            }
          }
        );
      }
    }
  );
});
const getWishListPlaces = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = connection.query(
    "SELECT * FROM user where email=?",
    [email],
    (error, results) => {
      if (error) {
        res.render("wishListPlaces", { message: "Couldn't get places" });
      } else {
        const places = connection.query(
          "SELECT loc_id FROM guest_wishlist where user_id=?",
          [results[0].user_id],
          (error, results) => {
            if (error) {
              console.log(error);
              res.render("wishListPlaces", { message: "Couldn't get places" });
            } else if (results.length == 0) {
              res.render("wishListPlaces", {
                message: "No places in wishlist",
              });
            } else {
              const loc_ids = results.map((r) => r.loc_id);
              const places = connection.query(
                "SELECT * FROM place where loc_id in (?)",
                [loc_ids],
                (error, results) => {
                  if (error) {
                    res.render("wishListPlaces", {
                      message: "Couldn't get places",
                    });
                  } else {
                    res.render("wishListPlaces", { places: results });
                    // res.json(results[0]);
                  }
                }
              );
              // res.json(results);
            }
          }
        );
        // res.json(results);
      }
    }
  );
});
const deletePlace = asyncHandler(async (req, res) => {
  const { loc_id, email } = req.body;
  const user = connection.query(
    "SELECT user_id,isAdmin FROM user WHERE email = ?",
    [email],
    (error, results) => {
      if (error) {
        res.render("deletePlace", { message: "Error" });
      } else if (results[0].isAdmin == "no") {
        res.render("deletePlace", { message: "You are not an admin" });
      } else {
        connection.query(
          "SELECT * FROM place WHERE loc_id = ?",
          [loc_id],
          (error, results) => {
            if (error) {
              res.render("deletePlace", { message: "Error" });
            } else if (results[0].isBooked == "yes") {
              res.render("deletePlace", {
                message: "Place is already booked, cant delete it",
              });
            } else {
              connection.query(
                "DELETE FROM place WHERE loc_id=?",
                [loc_id],
                (error, results) => {
                  if (error) {
                    console.log(error);
                    res.render("deletePlace", { message: "Error" });
                  } else {
                    res.render("deletePlace", { message: "Place Removed" });
                  }
                }
              );
            }
          }
        );
      }
    }
  );
});
const getBookedPlaces = asyncHandler(async (req, res) => {
  const places = connection.query(
    "SELECT * FROM place where isBooked=?",
    ["yes"],
    (error, results) => {
      if (error) {
        res.render("bookedPlaces", { message: "Couldn't get places" });
      } else {
        res.render("bookedPlaces", { places: results });
        // res.json(results[0]);
      }
    }
  );
});

const checkOutFromPlace = asyncHandler(async (req, res) => {
  const { loc_id, email, review, rating } = req.body;
  const user = connection.query(
    "SELECT user_id FROM user WHERE email = ?",
    [email],
    (error, results) => {
      if (error) {
        res.render("addReview", { message: "Couldn't Find Email" });
      } else {
        const userid = results[0].user_id;
        connection.query(
          "SELECT * FROM place WHERE loc_id = ?",
          [loc_id],
          (error, results) => {
            if (error) {
              res.render("addReview", {
                message: "Couldn't Find Place",
              });
            } else if (results[0].isBooked == "no") {
              res.render("addReview", {
                message: "Place is not booked",
              });
            } else {
              connection.query(
                "SELECT * FROM guest_books where user_id=?",
                [userid],
                (error, results) => {
                  if (error) {
                    res.render("addReview", {
                      message: "Couldn't Find User",
                    });
                  } else if (results[0].loc_id != loc_id) {
                    res.render("addReview", {
                      message: "User is not booked to this place",
                    });
                  } else {
                    connection.query(
                      "UPDATE place SET isBooked=? WHERE loc_id=?",
                      ["no", loc_id],
                      (error, results) => {
                        if (error) {
                          res.render("addReview", {
                            message: "Couldn't Update Place",
                          });
                        } else {
                          connection.query(
                            "INSERT INTO user_vist_hist(user_id,loc_id,review,rating) VALUES(?,?,?,?)",
                            [userid, loc_id, review, rating],
                            (error, results) => {
                              if (error) {
                                console.log(error);
                                res.render("addReview", {
                                  message: "Couldn't Add Review",
                                });
                              } else {
                                connection.query(
                                  "DELETE FROM guest_books where user_id=?",
                                  [userid],
                                  (error, results) => {
                                    if (error) {
                                      res.render("addReview", {
                                        message: "Couldn't Delete Booking",
                                      });
                                    } else {
                                      res.render("addReview", {
                                        message: "Checked Out",
                                      });
                                    }
                                  }
                                );
                              }
                            }
                          );
                        }
                      }
                    );
                  }
                }
              );
            }
          }
        );
      }
    }
  );
});
// const user = connection.query(
//   "SELECT user_id FROM user WHERE email = ?",
//   [email],
//   (error, results) => {
//     if (error) {
//       res.render("checkOutFromPlace", { message: "Error" });
//     } else {
//       const userid = results[0].user_id;
//       connection.query(
//         "SELECT * FROM place WHERE loc_id = ?",
//         [loc_id],
//         (error, results) => {
//           if (error) {
//             res.render("checkOutFromPlace", { message: "Error" });
//           } else if (results[0].isBooked == "no") {
//             res.render("checkOutFromPlace", {
//               message: "Place is not booked",
//             });
//           } else {
//             connection.query("SELECT * from guest_books where loc_id=? and user_id=?", [loc_id,userid], (error, results) => {
//               if (error) {
//                 res.render("checkOutFromPlace", { message: "Error" });
//               } else if (results.length == 0) {
//                 res.render("checkOutFromPlace", {
//                   message: "You are not a guest of this place",
//                 });
//               } else {
//             connection.query(
//               "UPDATE place SET isBooked=? WHERE loc_id=?",
//               ["no", loc_id],
//               (error, results) => {
//                 if (error) {
//                   console.log(error);
//                   res.render("checkOutFromPlace", { message: "Error" });
//                 } else {
//                   connection.query(
//                     "INSERT INTO review(user_id,loc_id,review,rating) VALUES(?,?,?,?)",
//                     [results[0].user_id, loc_id, review, rating],
//                     (error, results) => {
//                       if (error) {
//                         console.log(error);
//                         res.render("checkOutFromPlace", {
//                           message: "Error",
//                         });
//                       } else {
//                         res.render("checkOutFromPlace", {
//                           message: "Place checked out",
//                         });
//                       }});
//                     }});
//                   }});
//                 }});
//               }});
//             });

// const user = connection.query(
//   "SELECT * FROM user WHERE email=?",
//   [email],
//   (error, results) => {
//     if (error) {
//       res.render("addReview", { message: "Error" });
//     } else {
//       console.log(results[0].user_id);
//       connection.query(
//         "SELECT * FROM guest_books WHERE user_id=? and loc_id=?",
//         [results[0].user_id, loc_id],
//         (error, results) => {
//           if (error) {
//             res.render("addReview", { message: "Error in query" });
//           } else if (results.length == 0) {
//             res.render("addReview", {
//               message: "You are not booked to this place",
//             });
//           } else {
//             connection.query(
//               "UPDATE place SET isBooked=? WHERE loc_id=?",
//               ["no", loc_id],
//               (error, results) => {
//                 if (error) {
//                   res.render("addReview", { message: "Error" });
//                 } else {
//                   connection.query(
//                     "INSERT INTO guest_reviews(user_id,loc_id,review,rating) VALUES(?,?,?,?)",
//                     [user_id, loc_id, review, rating],
//                     (error, results) => {
//                       if (error) {
//                         res.render("Index", {
//                           message: "Error",
//                         });
//                       } else {
//                         res.render("Index", {
//                           message: "Checked out from place",
//                         });
//                       }
//                     }
//                   );
//                 }
//               }
//             );
//           }
//         }
//       );
//     }
//   }
// );

const getReviews = asyncHandler(async (req, res) => {
  const { loc_id } = req.body;
  const reviews = connection.query(
    "SELECT * FROM user_vist_hist WHERE loc_id=?",
    [loc_id],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("reviews", { message: "Error" });
      } else {
        res.render("reviews", { reviews: results });
        // res.json(results[0]);
      }
    }
  );
});

const searchPlaces = asyncHandler(async (req, res) => {
  const { placeName } = req.body;
  const places = connection.query(
    "SELECT * FROM place WHERE loc_name = ?",
    [placeName],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("Index", { message: "Can't Find The Place " });
      } else {
        res.render("Index", { places: results });
        // res.json(results[0]);
      }
    }
  );
});

const searchByAnemities = asyncHandler(async (req, res) => {
  const { features, essential, space_type, property_type } = req.body;
  const places = connection.query(
    "SELECT * FROM place WHERE space_type=? and property_type=?",
    [space_type, property_type],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("searchByAnemities", {
          message: "Sorry, Couldn't find place of that type",
        });
      } else {
        connection.query(
          "SELECT * FROM place p,essentials e,features f WHERE p.loc_id = e.loc_id AND p.loc_id = f.loc_id AND e.essential in (?) AND f.feature in (?)",
          [essential, features],
          (error, results) => {
            if (error) {
              res.render("searchByAnemities", {
                message:
                  "Sorry, Couldn't find place with the facilities Mentioned",
              });
            } else {
              res.render("searchByAnemities", { places: results });
            }
          }
        );
      }
    }
  );
});

const searchByPrice = asyncHandler(async (req, res) => {
  const { maxprice } = req.body;
  // console.log(req.body);
  const places = connection.query(
    "SELECT * FROM place WHERE price_per_night <= ?",
    [maxprice],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("SearchedByPrice", { message: "Can't Find The Place " });
      } else if (results.length == 0) {
        res.render("SearchedByPrice", { message: "No places found" });
      } else {
        res.render("SearchedByPrice", { places: results });
        // res.json(results[0]);
      }
    }
  );
});
const searchByGuestCount = asyncHandler(async (req, res) => {
  const { guestCount } = req.body;
  const places = connection.query(
    "SELECT * FROM place WHERE max_guest >= ?",
    [guestCount],
    (error, results) => {
      if (error) {
        console.log(error);
        res.render("SearchedByGuests", { message: "Can't Find The Place" });
      } else if (results.length == 0) {
        res.render("SearchedByGuests", { message: "No places found" });
      } else {
        res.render("SearchedByGuests", { places: results });
        // res.json(results[0]);
      }
    }
  );
});
module.exports = {
  bookPlace,
  getAvailablePlaces,
  getWishListPlaces,
  getBookedPlaces,
  deletePlace,
  addWishListPlace,
  registerPlace,
  checkOutFromPlace,
  getReviews,
  searchPlaces,
  searchByAnemities,
  searchByGuestCount,
  searchByPrice,
};
