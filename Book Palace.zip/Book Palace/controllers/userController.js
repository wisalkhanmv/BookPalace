const asyncHandler = require("express-async-handler");
const { render } = require("express/lib/response");
const { connect } = require("../database.js");
const connection = require("../database.js");

// @desc    Register new user
// @route   POST /api/users
// @access  Public
const register = asyncHandler(async (req, res) => {
  // res.render("../views/register");
  console.log(req.body);
  const { username, mobile, email, password, confirmPassword } = req.body;
  if (!username || !email || !password) {
    res.status(400);
    throw new Error("Please add all fields");
  }
  connection.query(
    "SELECT * FROM user WHERE email = ?",
    [email],
    async (error, results) => {
      if (error) {
        console.log(error);
      }
      if (results.length > 0) {
        return res.render("register", {
          message: "That email is already in use",
        });
      } else if (password != confirmPassword) {
        return res.render("register", { message: "Passwords do not match" });
      }
      connection.query(
        "INSERT INTO user (name, phone, email, pwd) VALUES (?, ?, ?, ?)",
        [username, mobile, email, password],
        (error, results) => {
          if (error) {
            console.log(error);
          } else {
            console.log("user added");
            return res.render("register", {
              message: "User Registered",
            });
          }
        }
      );
    }
  );
});

// @desc    Authenticate a user
// @route   POST /api/users/login
// @access  Public
const login = asyncHandler(async (req, res) => {
  // res.render("Login");
  const { email, password } = req.body;
  // Check for user email
  // console.log(connection);
  const user = connection.query(
    "SELECT * FROM user WHERE email = ?",
    [email],
    (err, results) => {
      if (!results.length) {
        return res.render("Login", {
          message: "No user found",
        });
      }
      // Check for password
      if (user.pwd == results[0].password) {
        const payload = {
          id: results[0].user_id,
          name: results[0].name,
        };
        connection.query(
          "UPDATE user SET log_status=? WHERE user_id=?",
          ["yes", results[0].user_id],
          (error, results) => {
            if (error) {
              console.log("Can't connnect");
            } else {
              console.log("Logged IN");
              // console.log(results);
            }
          }
        );
        res.render("Index", {
          message: "You are now logged in",
          user: req.user,
        });
      } else {
        return res.render("Login", {
          message: "Password incorrect",
        });
      }
    }
  );
});

// @desc    Get user data
// @route   GET /api/users/me
// @access  Private
const getMe = asyncHandler(async (req, res) => {
  // res.status(200).json(req.user);
  // res.render("profile");
  // res.redirect("/getMe");
  const user = connection.query(
    "SELECT * FROM user WHERE email = ?",
    [req.body.email],
    (err, results) => {
      console.log(results[0]);
      res.render("profile", { user: results[0] });
    }
  );
});

const logout = asyncHandler(async (req, res) => {
  // res.status(200).json(req.user);
  // res.render("profile");
  // res.redirect("/getMe");
  const email = req.body.email;
  const user = connection.query(
    "SELECT * FROM user WHERE email = ?",
    [email],
    (err, results) => {
      connection.query({
        sql: "UPDATE user  SET log_status=? WHERE user_id=?",
        values: ["no", results[0].user_id],
      });
      console.log(results[0].user_id);
      res.render("Login", { user: req.user });
    }
  );
});

module.exports = {
  register,
  login,
  getMe,
  logout,
};
