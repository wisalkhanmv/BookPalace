const express = require("express");
const router = express.Router();
router.get("/", (req, res) => {
  res.render("Login");
});
router.get("/Contact", (req, res) => {
  res.render("Contact");
});
router.get("/About", (req, res) => {
  res.render("About");
});
router.get("/Home", (req, res) => {
  res.render("Index");
});

module.exports = router;
