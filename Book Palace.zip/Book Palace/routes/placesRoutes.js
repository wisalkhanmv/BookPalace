const express = require("express");
const {
  registerPlace,
  bookPlace,
  getWishListPlaces,
  addWishListPlace,
  deletePlace,
  getAvailablePlaces,
  getBookedPlaces,
  checkOutFromPlace,
  getReviews,
  searchPlaces,
  searchByPrice,
  searchByGuestCount,
  searchByAnemities,
} = require("../controllers/placeController");
const router = express.Router();
router.post("/registerPlace", registerPlace);
router.get("/registerPlace", (req, res) => {
  res.render("registerPlace");
});
router.post("/bookPlace", bookPlace);
router.get("/bookPlace", (req, res) => {
  res.render("bookPlace");
});
router.post("/getWishListPlaces", getWishListPlaces);
router.post("/addWishListPlace", addWishListPlace);
router.get("/addWishListPlace", (req, res) => {
  res.render("addWishListPlace");
});
router.get("/getAvailablePlaces", getAvailablePlaces);
router.get("/getBookedPlaces", getBookedPlaces);
router.post("/deletePlace", deletePlace);
router.get("/deletePlace", (req, res) => {
  res.render("deletePlace");
});
router.post("/checkOutFromPlace", checkOutFromPlace);
router.get("/checkOutFromPlace", (req, res) => {
  res.render("addReview");
});
router.post("/getReviews", getReviews);
router.get("/getReviews", (req, res) => {
  res.render("whoseReview");
});

router.post("/searchPlaces", searchPlaces);
router.get("/searchPlaces", (req, res) => {
  res.render("Index");
});

router.get("/searchByAnemities", (req, res) => {
  res.render("searchByAnemities");
});
router.post("/searchByAnemities", searchByAnemities);

router.get("/searchByGuestCount", (req, res) => {
  res.render("SearchedByGuestCount");
});
router.post("/searchByGuestCount", searchByGuestCount);

router.get("/searchByPrice", (req, res) => {
  res.render("SearchedByPrice");
});
router.post("/searchByPrice", searchByPrice);

module.exports = router;
