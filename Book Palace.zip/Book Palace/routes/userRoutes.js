const express = require("express");
const {
  register,
  login,
  logout,
  getMe,
} = require("../controllers/userController.js");
const router = express.Router();
const connection = require("../database");
const passport = require("passport");

router.post("/register", register);
router.get("/register", (req, res) => {
  res.render("register");
});

router.post("/login", login);
router.get("/login", (req, res) => {
  res.render("Login");
});

router.post("/logout", logout);

router.get("/profile", getMe);

module.exports = router;
