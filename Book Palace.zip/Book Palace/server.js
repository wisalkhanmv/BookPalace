const express = require("express");
const app = express();
const hbs = require("handlebars");
const path = require("path");
const dotenv = require("dotenv");
// const passport = require("passport");
// const flash = require("express-flash");
// const session = require("express-session");
// const initialize = require("./passport-config");
// const connection = require("./database");
dotenv.config();

//database
// const mysql = require("mysql");
// var connection = mysql.createConnection({
//   host: process.env.host,
//   user: process.env.user,
//   password: process.env.password,
//   database: process.env.database,
//   port: process.env.dbport,
//   multipleStatement: true,
// });

const { userInfo } = require("os");
const { allowedNodeEnvironmentFlags } = require("process");
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/api/user", require("./routes/userRoutes"));
app.use("/", require("./routes/pagesRoutes"));
app.use("/api/places", require("./routes/placesRoutes"));

const port = process.env.PORT || 3000;

app.set("view engine", "hbs");

const publicDirectory = path.join(__dirname, "./public");
app.use(express.static(publicDirectory));

//*************MIDDLEWARE************
//get users
// const getAll = (req, res) => {
//   connection.query(
//     { sql: "SELECT * FROM `user` WHERE `name`!=?", values: [""] },
//     (err, results) => {
//       console.log(results);
//       return results;
//     }
//   );
// };
// app.use(getAll);
// const users = getAll();
//********************************************************* */

//**************Passport**********************//
// initialize(
//   passport,
//   (email) => users.find((user) => user.email === email),
//   (id) => users.find((user) => user.user_id === id)
// );
// app.use(flash());
// app.use(
//   session({
//     secret: "bookPalace",
//     resave: false,
//     saveUninitialized: false,
//   })
// );
// app.use(passport.initialize());
// app.use(passport.session());

//**************Passport End******************* */

//MIDDLEWARE
// const isLoggedIn = (req, res, next) => {
//   if (req.isAuthenticated()) {
//     return next();
//   }
//   res.redirect("/login");
// };
// app.use(isLoggedIn);
//*************Middleware end********************** */

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
